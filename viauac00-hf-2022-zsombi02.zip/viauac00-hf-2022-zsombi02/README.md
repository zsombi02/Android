# Házi feladat specifikáció

Információk [itt](https://viauac00.github.io/laborok/hf)

## Mobil- és webes szoftverek
### 2022 10 23
### A La Pizzeria
### Szabadkai Zsombor - (P7XRW7)
### szabadkaizsombor@gmail.com 
### Laborvezető: Főglein Simon

## Bemutatás

### Az alkalmazásom egy pizzériában használatos segédalkalmazás lesz. Az ötlet a kedvenc öntevékeny körömben való foglalkozásból származik, a Pizzáschból.
### Hasznos lehet mindenki számára aki pizzát szeret készíteni, akár nagyobb akár kisebb tételben.


## Főbb funkciók

### Az alkalmazásban lehetőség van az elérhető alapanyagok listázására, hozzáadására, kitörlésére egy adatbázisból.
### Funkció arra, hogy leellenőrizzük, hogy X kg tészta elkészítéséhez van e elegendő alapanyagunk, és ha nincs akkor mennyi hiányzik
### Funkció ahol listázva vannak a különböző pizzafajták, és az azokhoz szükséges feltétek illetve megjegyzések, ugyanitt jelzi ha egy feltét nem elérhető
### Funkció, az adott nyitás alkalmával elkészített pizzák nyilvántartására db/típus módon


## Választott technológiák:

- (UI)
- (fragmentek)
- (RecyclerView)
- (Perzisztens adattárolás)


# Házi feladat dokumentáció (ha nincs, ez a fejezet törölhető)