package hu.bme.aut.android.nagyhf

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import hu.bme.aut.android.nagyhf.adapter.CounterAdapter
import hu.bme.aut.android.nagyhf.adapter.IngredientAdapter
import hu.bme.aut.android.nagyhf.adapter.PizzaAdapter
import hu.bme.aut.android.nagyhf.databinding.FragmentCounterBinding
import hu.bme.aut.android.nagyhf.databinding.FragmentPizzasBinding
import hu.bme.aut.android.nagyhf.pincadata.Pizzas
import hu.bme.aut.android.nagyhf.pincadata.pizzaDatabase
import kotlin.concurrent.thread


class CounterFragment : Fragment(), CounterAdapter.CounterClickListener {

    private  lateinit var binding: FragmentCounterBinding
    private lateinit var database: pizzaDatabase
    private lateinit var adapter: CounterAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?) : View {
        binding = FragmentCounterBinding.inflate(inflater,container,false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        database =pizzaDatabase.getDatabase(requireContext().applicationContext)

        initRecyclerView()

        loadItemsInBackground()
        binding.btnreset.setOnClickListener{
            onReset()
        }

    }

    private fun initRecyclerView(){
        adapter= CounterAdapter(this)
        binding.rvMain.layoutManager = LinearLayoutManager(activity)
        binding.rvMain.adapter = adapter
        loadItemsInBackground()
    }
    private fun loadItemsInBackground() {
        thread {
            val items = database.pizzaDAO().getAll()
            activity?.runOnUiThread {
                adapter.update(items)
            }
        }
    }

    override fun onPizzaChanged(item: Pizzas) {
        thread {
            database.pizzaDAO().update(item)
            val items = database.pizzaDAO().getAll()
            activity?.runOnUiThread {
            adapter.update(items)
            }
        }
    }

    fun onReset() {
        thread {
            val items = database.pizzaDAO().getAll()
            items.forEach {
                it.amount = 0
                database.pizzaDAO().update(it)
            }
            activity?.runOnUiThread {  adapter.reset()}
        }
    }


}