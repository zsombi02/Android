package hu.bme.aut.android.nagyhf

import android.app.AlertDialog
import android.app.Dialog
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.ArrayAdapter
import androidx.fragment.app.DialogFragment
import hu.bme.aut.android.nagyhf.data.Ingredient
import hu.bme.aut.android.nagyhf.databinding.DialogNewIngredientBinding
import hu.bme.aut.android.nagyhf.databinding.FragmentIngredientsBinding
import java.lang.RuntimeException

class NewIngredientFragment : DialogFragment() {
    interface  NewIngredientListener {
        fun onIngredientCreated(newItem: Ingredient)
    }
    private  lateinit var listener: NewIngredientListener
    private lateinit var binding: DialogNewIngredientBinding

    override fun onAttach(context: Context) {
        super.onAttach(context)
        listener = context as? NewIngredientListener
            ?: throw RuntimeException("Activity must implement the NewIngredientListener if")
    }

     override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
       binding = DialogNewIngredientBinding.inflate(LayoutInflater.from(context))
        binding.spCategory.adapter = ArrayAdapter(requireContext(), android.R.layout.simple_spinner_dropdown_item, resources.getStringArray(R.array.Units))
        return AlertDialog.Builder(requireContext()).setTitle("Alapanyag hozzáadása").setView(binding.root).setPositiveButton("Ok") {
                dialogInterface, i ->
            if (isValid())
            {
                listener.onIngredientCreated(getIngredient())
                
            }
        }
            .setNegativeButton("Cancel", null).create()
    }
    companion object {
        const val TAG = "NewIngredient"
    }
    private fun isValid() = (binding.name.text.isNotEmpty() && binding.etamount.text.isNotEmpty())

    private fun getIngredient() = Ingredient(
        name = binding.name.text.toString(),
        amount = binding.etamount.text.toString().toInt(),
        si = Ingredient.Units.getByOrdinal(binding.spCategory.selectedItemPosition)
            ?: Ingredient.Units.Db
    )

}