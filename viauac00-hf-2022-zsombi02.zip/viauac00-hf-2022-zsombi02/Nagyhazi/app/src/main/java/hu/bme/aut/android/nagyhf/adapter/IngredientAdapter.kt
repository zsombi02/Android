package hu.bme.aut.android.nagyhf.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import hu.bme.aut.android.nagyhf.data.Ingredient
import hu.bme.aut.android.nagyhf.databinding.ItemIngredientBinding

class IngredientAdapter(private val listener: IngredientClickListener) :
RecyclerView.Adapter<IngredientAdapter.IngredientViewHolder>() {


    private val items = mutableListOf<Ingredient>()
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ) =  IngredientViewHolder(ItemIngredientBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: IngredientViewHolder, position: Int) {
       val ingredientItem = items[position]
        holder.binding.tvName.text = ingredientItem.name
        holder.binding.tvamount.text = "${ingredientItem.amount}"
        holder.binding.tvsi.text = ingredientItem.si.name
        holder.binding.ibdelete.setOnClickListener{
            deleteItem(ingredientItem)
            listener.onDelete(ingredientItem)
        }
        holder.binding.ibadd.setOnClickListener{

            ingredientItem.amount = ingredientItem.amount +5
            listener.onItemChanged(ingredientItem)
        }
        holder.binding.ibRemove.setOnClickListener {
            if(ingredientItem.amount > 0)
            {ingredientItem.amount = ingredientItem.amount -1
            listener.onItemChanged(ingredientItem)}
        }
        if(ingredientItem.amount ==0)
            holder.binding.root.setBackgroundColor(Color.RED)
        else
            holder.binding.root.setBackgroundColor(Color.TRANSPARENT)
    }

    fun addItem(item: Ingredient)
    {
        items.add(item)
        notifyItemInserted(items.size -1)
    }

    fun update(Ingredients: List<Ingredient>)
    {
        items.clear()
        items.addAll(Ingredients)
        notifyDataSetChanged()
    }

    fun deleteItem(item: Ingredient)
    {
        items.remove(item)
        notifyDataSetChanged()
    }



    override fun getItemCount(): Int = items.size

    interface IngredientClickListener{
        fun onItemChanged(item: Ingredient)
        fun onDelete(item: Ingredient)

    }
    inner class IngredientViewHolder(val binding : ItemIngredientBinding) : RecyclerView.ViewHolder(binding.root)

}