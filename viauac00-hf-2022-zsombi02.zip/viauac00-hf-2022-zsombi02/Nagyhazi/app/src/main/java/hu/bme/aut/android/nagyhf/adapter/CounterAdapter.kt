package hu.bme.aut.android.nagyhf.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import hu.bme.aut.android.nagyhf.data.Ingredient
import hu.bme.aut.android.nagyhf.pincadata.Pizzas
import hu.bme.aut.android.nagyhf.databinding.FragmentCounterBinding
import hu.bme.aut.android.nagyhf.databinding.ItemCounterBinding

class CounterAdapter(private val listener: CounterAdapter.CounterClickListener) :
    RecyclerView.Adapter<CounterAdapter.CounterViewHolder>() {


    private val items = mutableListOf<Pizzas>()
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ) =  CounterViewHolder(ItemCounterBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: CounterViewHolder, position: Int) {
        val PizzaItem = items[position]
        holder.binding.tvName.text = PizzaItem.name
        holder.binding.tvamount.text = PizzaItem.amount.toString()
        holder.binding.ibadd.setOnClickListener {
            PizzaItem.amount = PizzaItem.amount +1
            listener.onPizzaChanged(PizzaItem)
        }
        holder.binding.ibRemove.setOnClickListener {
            PizzaItem.amount = PizzaItem.amount -1
            listener.onPizzaChanged(PizzaItem)
        }


    }

    fun addItem(item: Pizzas)
    {
        items.add(item)
        notifyItemInserted(items.size -1)
    }

    fun reset()
    {
        items.forEach { it.amount = 0 }
        notifyDataSetChanged()
    }
    fun update(Pizzas: List<Pizzas>)
    {
        items.clear()
        items.addAll(Pizzas)
        notifyDataSetChanged()
    }

    fun deleteItem(item: Pizzas)
    {
        items.remove(item)
        notifyDataSetChanged()
    }



    override fun getItemCount(): Int = items.size

    interface CounterClickListener{
        fun onPizzaChanged(item: Pizzas)

    }
    inner class CounterViewHolder(val binding : ItemCounterBinding) : RecyclerView.ViewHolder(binding.root)

}