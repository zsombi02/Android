package hu.bme.aut.android.nagyhf.data

import android.content.Context
import androidx.room.*

@Database(entities = [Ingredient::class], version = 1)

abstract class IngredientDatabase: RoomDatabase()
{
    abstract fun IngredientDAO(): IngredientDAO

    companion object{
        fun getDatabase(applicationContext: Context) : IngredientDatabase {
        return Room.databaseBuilder(
            applicationContext,
            IngredientDatabase::class.java,
            "ingredients"
        ).build()
        }
    }
}