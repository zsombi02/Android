package hu.bme.aut.android.nagyhf.pincadata

import androidx.room.*
import hu.bme.aut.android.nagyhf.data.Ingredient

@Dao
interface pizzaDAO {
    @Query("SELECT * FROM pizzas")
    fun getAll(): List<Pizzas>

    @Insert
    fun insert(pizza: Pizzas): Long

    @Update
    fun update(pizza: Pizzas)

    @Delete
    fun deleteItem(pizza: Pizzas)
}