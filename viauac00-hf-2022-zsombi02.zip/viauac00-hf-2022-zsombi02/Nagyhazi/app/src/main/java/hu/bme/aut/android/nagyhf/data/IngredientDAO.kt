package hu.bme.aut.android.nagyhf.data

import androidx.room.*

@Dao
interface IngredientDAO {
    @Query("SELECT * FROM ingredients")
    fun getAll(): List<Ingredient>

    @Insert
    fun insert(ingredient: Ingredient): Long

    @Update
    fun update(ingredient: Ingredient)

    @Delete
    fun deleteItem(ingredient: Ingredient)
}