package hu.bme.aut.android.nagyhf

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import hu.bme.aut.android.nagyhf.adapter.IngredientAdapter
import hu.bme.aut.android.nagyhf.adapter.PizzaAdapter
import hu.bme.aut.android.nagyhf.databinding.FragmentPizzasBinding
import hu.bme.aut.android.nagyhf.pincadata.Pizzas
import hu.bme.aut.android.nagyhf.pincadata.pizzaDatabase
import kotlin.concurrent.thread


class PizzasFragment : Fragment() {

    private  lateinit var binding: FragmentPizzasBinding
    private lateinit var database: pizzaDatabase
    private lateinit var adapter: PizzaAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,savedInstanceState: Bundle?) : View {
       binding = FragmentPizzasBinding.inflate(inflater,container,false)
        return binding.root

    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        database =pizzaDatabase.getDatabase(requireContext().applicationContext)

        initRecyclerView()
        thread {
            if (database.pizzaDAO().getAll().isEmpty()) {

                database.pizzaDAO().insert(Pizzas(1, "Margharita", "Paradicsom alap, Sajt, Paradicsom", 0))
                database.pizzaDAO().insert(Pizzas(2, "Szalámis", "Paradicsomos alap, Sajt, Szalami",  0))
                database.pizzaDAO().insert(Pizzas(3, "Sonkás", "Paradicsomos alap, Sajt, Sonka" ,0))
                database.pizzaDAO().insert(Pizzas(4, "Pestiest", "Fokhagymás alap, Sonka, Kukorica, Sajt, Cheddar",0 ))
                database.pizzaDAO().insert(Pizzas(5, "Joker", "Paradicsom alap, Szalámi, Bacon, Lilahagyma, Sajt",0 ))
                database.pizzaDAO().insert(Pizzas(6, "Kusza", "Paradicsom alap, Kukorica, Szalámi, Sajt",0 ))
                database.pizzaDAO().insert(Pizzas(7, "Sonku", "Paradicsom alap, Kukorica, Sonka, Sajt",0 ))
                database.pizzaDAO().insert(Pizzas(8, "Songoku", "Paradicsom alap, Kukorica, Sonka, Gomba, Sajt",0 ))
                database.pizzaDAO().insert(Pizzas(9, "BBQ", "BBQ alap, Bacon, Sonka, Lilahagyma, Sajt",0 ))
                database.pizzaDAO().insert(Pizzas(10, "Kaszanova", "Fokhagymás  alap, Bacon, Sajt",0 ))
                database.pizzaDAO().insert(Pizzas(11, "Ördög", "Csípős  alap, Bacon, Szalámi, Jalapeno, Sajt",0 ))
                database.pizzaDAO().insert(Pizzas(12, "Fullos", "Paradicsomos alap, Bacon, Szalámi, Jalapeno, Sajt",0 ))
            }
        }
        //initRecyclerView()
    binding.btnszamolo.setOnClickListener{
        findNavController().navigate(R.id.action_pizzasFragment_to_counterFragment)
    }

    }

    private fun initRecyclerView(){
        adapter= PizzaAdapter()
        binding.rvMain.layoutManager = LinearLayoutManager(activity)
        binding.rvMain.adapter = adapter
        loadItemsInBackground()
    }
    private fun loadItemsInBackground() {
        thread {
            val items = database.pizzaDAO().getAll()
            activity?.runOnUiThread {
                adapter.update(items)
            }
        }
    }


}