package hu.bme.aut.android.nagyhf

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.recyclerview.widget.LinearLayoutManager
import hu.bme.aut.android.nagyhf.adapter.IngredientAdapter
import hu.bme.aut.android.nagyhf.data.Ingredient
import hu.bme.aut.android.nagyhf.data.IngredientDatabase
import hu.bme.aut.android.nagyhf.databinding.FragmentIngredientsBinding
import kotlin.concurrent.thread

class Ingredients : AppCompatActivity() , NewIngredientFragment.NewIngredientListener, IngredientAdapter.IngredientClickListener{



    private  lateinit var binding: FragmentIngredientsBinding
    private lateinit var database: IngredientDatabase
    private lateinit var adapter: IngredientAdapter



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = FragmentIngredientsBinding.inflate(layoutInflater)
        setContentView(binding.root)
        setSupportActionBar(binding.toolbar)

        database = IngredientDatabase.getDatabase(applicationContext)
        binding.fab.setOnClickListener{
            //var manager = (IngredientsFragment.context as FragmentActivity)

            NewIngredientFragment().show(
                supportFragmentManager,
                NewIngredientFragment.TAG
            )

        }

        initRecyclerView()
    }

    private fun initRecyclerView(){
        adapter= IngredientAdapter(this)
        binding.rvMain.layoutManager = LinearLayoutManager(this)
        binding.rvMain.adapter = adapter
        loadItemsInBackground()
    }
    private fun loadItemsInBackground() {
        thread {
            val items = database.IngredientDAO().getAll()
            runOnUiThread {
                adapter.update(items)
            }
        }
    }

    override fun onIngredientCreated(newItem: Ingredient) {
        thread {
            val insertiD = database.IngredientDAO().insert(newItem)
            newItem.id = insertiD
            runOnUiThread{
                adapter.addItem(newItem)
            }
        }
    }


    override fun onItemChanged(item: Ingredient) {
        thread {
            database.IngredientDAO().update(item)
            val items = database.IngredientDAO().getAll()
            runOnUiThread { adapter.update(items) }
        }
    }

    override fun onDelete(item: Ingredient) {
        thread {
            database.IngredientDAO().deleteItem(item)
            val items = database.IngredientDAO().getAll()
            runOnUiThread {
                adapter.deleteItem(item)
                adapter.update(items)

            }
        }
    }


}