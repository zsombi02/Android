package hu.bme.aut.android.nagyhf.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import hu.bme.aut.android.nagyhf.pincadata.Pizzas
import hu.bme.aut.android.nagyhf.databinding.ItemPindzaBinding

class PizzaAdapter :
    RecyclerView.Adapter<PizzaAdapter.PizzaViewHolder>() {


    private val items = mutableListOf<Pizzas>()
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ) =  PizzaViewHolder(ItemPindzaBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: PizzaViewHolder, position: Int) {
        val PizzaItem = items[position]
        holder.binding.tvName.text = PizzaItem.name
        holder.binding.tvingredients.text = PizzaItem.ingredients


    }

    fun addItem(item: Pizzas)
    {
        items.add(item)
        notifyItemInserted(items.size -1)
    }

    fun update(Pizzas: List<Pizzas>)
    {
        items.clear()
        items.addAll(Pizzas)
        notifyDataSetChanged()
    }

    fun deleteItem(item: Pizzas)
    {
        items.remove(item)
        notifyDataSetChanged()
    }



    override fun getItemCount(): Int = items.size


    inner class PizzaViewHolder(val binding : ItemPindzaBinding) : RecyclerView.ViewHolder(binding.root)

}