package hu.bme.aut.android.nagyhf.data

import androidx.room.*


@Entity(tableName = "ingredients")
data class Ingredient (
    @ColumnInfo(name = "id") @PrimaryKey(autoGenerate = true) var id: Long? = null,
    @ColumnInfo(name = "name") var name: String,
    @ColumnInfo(name = "amount") var amount: Int,
    //@ColumnInfo(name = "si") var si: Double,
    @ColumnInfo(name = "si") var si: Units

        )
{
enum class Units {
    Kg, Dkg, G, L, Dl, Ml, Db;

    companion object {
        @JvmStatic
        @TypeConverter
        fun getByOrdinal(ordinal: Int): Units? {
            var ret: Units? = null
            for (cat in values()) {
                if (cat.ordinal == ordinal) {
                    ret = cat
                    break
                }
            }
            return ret
        }

        @JvmStatic
        @TypeConverter
        fun toInt(category: Units): Int {
            return category.ordinal
        }
    }
}
}
