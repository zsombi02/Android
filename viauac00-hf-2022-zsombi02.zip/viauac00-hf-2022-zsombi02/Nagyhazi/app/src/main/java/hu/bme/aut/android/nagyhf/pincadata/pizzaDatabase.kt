package hu.bme.aut.android.nagyhf.pincadata

import android.content.Context
import androidx.room.*
import hu.bme.aut.android.nagyhf.pincadata.Pizzas
import hu.bme.aut.android.nagyhf.pincadata.pizzaDAO

@Database(entities = [Pizzas::class], version = 1)

abstract class pizzaDatabase: RoomDatabase()
{
    abstract fun pizzaDAO(): pizzaDAO

    companion object{
        fun getDatabase(applicationContext: Context) : pizzaDatabase {
            return Room.databaseBuilder(
                applicationContext,
                pizzaDatabase::class.java,
                "pizzas"
            ).build()
        }
    }
}