package hu.bme.aut.android.nagyhf.pincadata

import androidx.room.*


@Entity(tableName = "pizzas")
data class Pizzas (
    @ColumnInfo(name = "id") @PrimaryKey(autoGenerate = true) var id: Long? = null,
    @ColumnInfo(name = "name") var name: String,
    @ColumnInfo(name = "Ingredients") var ingredients: String,
    @ColumnInfo(name = "Amount") var amount: Int

)
