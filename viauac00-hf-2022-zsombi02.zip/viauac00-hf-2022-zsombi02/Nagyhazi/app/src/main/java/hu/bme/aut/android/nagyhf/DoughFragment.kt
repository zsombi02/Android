package hu.bme.aut.android.nagyhf

import android.graphics.Color
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import hu.bme.aut.android.nagyhf.adapter.IngredientAdapter
import hu.bme.aut.android.nagyhf.data.Ingredient
import hu.bme.aut.android.nagyhf.data.IngredientDatabase
import hu.bme.aut.android.nagyhf.databinding.FragmentDoughBinding
import kotlin.concurrent.thread
import kotlin.math.round
import kotlin.math.roundToInt


class DoughFragment : Fragment(){
    private lateinit var binding: FragmentDoughBinding
    private lateinit var database: IngredientDatabase
    private lateinit var adapter: IngredientAdapter
    private var dough: Double = 0.0
    private var eleszto: Double = 0.0
    private var liszt: Double = 0.0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        binding = FragmentDoughBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?)
    {   super.onViewCreated(view, savedInstanceState)
        database = IngredientDatabase.getDatabase(requireContext().applicationContext)
        getneededDB(database)
        binding.btnok.setOnClickListener {
            if(binding.amount.text.toString().isEmpty())
            {
                Toast.makeText(activity, R.string.warn_message, Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
            dough =binding.amount.text.toString().toDouble()
            if(eleszto < dough*0.4) {
                binding.tvEleszto.setTextColor(Color.RED)
                binding.tvhianyzoeleszto.text = "${(dough*0.4-eleszto).roundToInt()} Darab Élesztő hiányzik"
            }
            else
            {   binding.tvEleszto.setTextColor(Color.GRAY)
                binding.tvhianyzoeleszto.text = ""
            }
            if(liszt < dough*0.625){
                binding.tvLiszt.setTextColor(Color.RED)
                binding.tvhianyzoliszt.text = "${(dough*0.4-liszt).roundToInt()} Kg Liszt hiányzik"
            }
            else{
                binding.tvLiszt.setTextColor(Color.GRAY)
                binding.tvhianyzoliszt.text = ""
            }

            binding.tvEleszto.text = "Élesztő: ${(dough * 0.4).roundToInt()} Darab"
            binding.tvLiszt.text = "Liszt: ${(dough * 0.625).roundToInt()} Kilogramm"
            binding.tvTeszta.text = "${dough.roundToInt()} Kg Tészta"
            binding.tvolaj.text = "Olaj: ${(dough*0.6).roundToInt()} Biccentés"
            binding.tvviz.text = "Víz: ${(dough*0.35).roundToInt()} Liter"


        }

    }

fun getneededDB(database: IngredientDatabase){
    thread {
        val items = database.IngredientDAO().getAll()
        for(i in items.indices)
        {
            if(items[i].name.toString().lowercase() == "élesztő" || items[i].name.toString().lowercase() == "eleszto" )
                eleszto += items[i].amount
            if(items[i].name.toString().lowercase() == "liszt" )
                if(items[i].si.toString() == "Kg")
                    liszt += items[i].amount.toDouble()
                if(items[i].si.toString() == "Dkg")
                    liszt += items[i].amount.toDouble()/100
                if(items[i].si.toString() == "G")
                liszt += items[i].amount.toDouble()/1000

        }
    }
}


}