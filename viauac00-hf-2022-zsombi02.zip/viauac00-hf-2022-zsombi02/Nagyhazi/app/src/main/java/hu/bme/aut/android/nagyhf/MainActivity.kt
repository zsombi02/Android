package hu.bme.aut.android.nagyhf

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import hu.bme.aut.android.nagyhf.adapter.IngredientAdapter
import hu.bme.aut.android.nagyhf.data.Ingredient
import hu.bme.aut.android.nagyhf.data.IngredientDatabase
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)



    }




}