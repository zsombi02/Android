package hu.bme.aut.android.weatherinfo.model

data class Cloud (
    var all: Int = 0
)