package hu.bme.aut.android.weatherinfo.model

data class Coord (
    var lon: Float = 0f,
    var lat: Float = 0f
)