package hu.bme.aut.android.weatherinfo.model

class Wind (
    val speed: Float = 0f,
    val deg: Float = 0f
)