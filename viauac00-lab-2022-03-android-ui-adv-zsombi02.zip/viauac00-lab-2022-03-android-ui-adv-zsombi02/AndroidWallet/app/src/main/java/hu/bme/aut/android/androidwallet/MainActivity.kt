package hu.bme.aut.android.androidwallet

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import hu.bme.aut.android.androidwallet.databinding.ActivityMainBinding
import hu.bme.aut.android.androidwallet.databinding.SalaryRowBinding


class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var rowBinding: SalaryRowBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        val contextView = findViewById<View>(R.id.myCoordinatorLayout)
        binding.saveButton.setOnClickListener {
            // TODO: ide jön az eseménykezelő kód
            if (binding.salaryName.text.toString().isEmpty() || binding.salaryAmount.text.toString().isEmpty()) {
                //Toast.makeText(this, R.string.warn_message, Toast.LENGTH_LONG).show()
                Snackbar.make(contextView, R.string.warn_message, Snackbar.LENGTH_SHORT)
                    .show()
                return@setOnClickListener
            }
            rowBinding = SalaryRowBinding.inflate(layoutInflater)
            rowBinding.salaryDirectionIcon.setImageResource(if (binding.expenseOrIncome.isChecked) R.drawable.expense else R.drawable.income)
            rowBinding.rowSalaryName.text = binding.salaryName.text.toString()
            rowBinding.rowSalaryAmount.text = binding.salaryAmount.text.toString()
            binding.listOfRows.addView(rowBinding.root)

        }
    }
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.action_delete_all -> {
                // TODO: itt fogjuk kezelni a kattintást
                binding.listOfRows.removeAllViews()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }
}